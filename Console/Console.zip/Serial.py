import serial
import time

class LoRa:
    def __init__(self, port="COM3", baudrate=115200):
        self.port = port
        self.baudrate = baudrate
        self.ser = None
        self.prev_datastring = None
        self.prev_time = 0.00  # Timestamp of the last write
        self.write_interval = 0.05  # Interval between writes in seconds (100 ms)

    def COM_INIT(self):
        try:
            self.ser = serial.Serial(self.port, self.baudrate, timeout=10)
            print(f"Connected to port: {self.port}")
        except serial.SerialException as e:
            print(f"Failed to connect to port: {self.port}. Error: {e}")

    def receive_telemetry(self):
        # Initialize default values for the variables
        P_FUEL_PUMP = P_OX_FEED = P_FUEL_INJ = P_OX_INJ = P_PURGE_TANK = Thrust = TEMP_D_SEC = TEMP_T_SEC = TEMP_C_SEC = TEMP_C_INLET = TEMP_CHAMBER = FUEL_VALVE = OXIDIZER_VALVE = PUMP_SPEED = 0
        if self.ser and self.ser.is_open:
            try:
                line = self.ser.readline().decode().strip()  # Read a line of data from the serial port
                if line:
                    # Map the telemetry data to the respective variables
                    data = line.split(',')
                    if len(data) == 9:
                        P_FUEL_PUMP, P_OX_FEED, P_FUEL_INJ, P_OX_INJ, P_PURGE_TANK, Thrust, FUEL_VALVE, OXIDIZER_VALVE, PUMP_SPEED = map(int, data)
                        return P_FUEL_PUMP, P_OX_FEED, P_FUEL_INJ, P_OX_INJ, P_PURGE_TANK, Thrust, FUEL_VALVE, OXIDIZER_VALVE, PUMP_SPEED
                        #P_FUEL_PUMP, P_OX_FEED, P_FUEL_INJ, P_OX_INJ, P_PURGE_TANK, Thrust, TEMP_D_SEC, TEMP_T_SEC, TEMP_C_SEC, TEMP_C_INLET, TEMP_CHAMBER, FUEL_VALVE, OXIDIZER_VALVE, PUMP_SPEED = map(int, data)
                        #return P_FUEL_PUMP, P_OX_FEED, P_FUEL_INJ, P_OX_INJ, P_PURGE_TANK, Thrust, TEMP_D_SEC, TEMP_T_SEC, TEMP_C_SEC, TEMP_C_INLET, TEMP_CHAMBER, FUEL_VALVE, OXIDIZER_VALVE, PUMP_SPEED

                    #else:
                        #print("Received data does not match expected format.")
            except (serial.SerialException, ValueError) as e:
                print(f"Error receiving telemetry data: {e}")
        else:
            print("Serial port is not open.")
            return P_FUEL_PUMP, P_OX_FEED, P_FUEL_INJ, P_OX_INJ, P_PURGE_TANK, Thrust, TEMP_D_SEC, TEMP_T_SEC, TEMP_C_SEC, TEMP_C_INLET, TEMP_CHAMBER, FUEL_VALVE, OXIDIZER_VALVE, PUMP_SPEED

    def send_data(self, ESTOP_STA, ARM_STA, MANUEL_CONTROLL_STA, V_OX_STA, V_FU_STA, PUMP_STA, PURGE_STA, IGNITOR_STA, IGN_SQ_STA):
        self.ESTOP_STA = ESTOP_STA                      # Estop status
        self.ARM_STA = ARM_STA                          # Arm status
        self.MANUEL_CONTROLL_STA = MANUEL_CONTROLL_STA  # Manuel control status
        self.V_OX_STA = V_OX_STA                        # Oxidizer valve status
        self.V_FU_STA = V_FU_STA                        # Fuel valve status
        self.PUMP_STA = PUMP_STA                        # Pump status
        self.PURGE_STA = PURGE_STA                      # Purge status
        self.IGNITOR_STA = IGNITOR_STA                  # Ignitor status
        self.IGN_SQ_STA = IGN_SQ_STA                    # Ignition sequence status
        
        if self.ser and self.ser.is_open:
            if time.time() - self.prev_time > self.write_interval:
                data_string = ','.join(map(str, [self.ESTOP_STA, self.ARM_STA, self.MANUEL_CONTROLL_STA, self.V_OX_STA, self.V_FU_STA, self.PUMP_STA, self.PURGE_STA, self.IGNITOR_STA, self.IGN_SQ_STA]))
                data_string += '\n'
                try:
                    self.ser.write(data_string.encode())
                    print(f"Sent: {data_string}")
                    self.prev_time = time.time()
                except serial.SerialException as e:
                    print(f"Error sending data: {e}")