import math 

def Incompressible_flow_orifice_calc():
    mdot=float(input("mdot(Kg/s):"))
    Cd=float(input("Cd:"))
    rho=float(input("density(Kg/m^3):"))
    deltaP=float(input("pressure different(MPa):"))*1000000
    A=mdot/(Cd*math.sqrt(2*rho*deltaP))*1000000
    d=math.sqrt(A/math.pi)*2
    print(f"orifice area:{A} mm^2")
    print(f"orifice diameter:{d} mm")
    
def Incompressible_flow_deltaP_calc():
    mdot=float(input("mdot(Kg/s):"))
    A=float(input("orifice area(mm^2):"))/1000000
    Cd=float(input("Cd:"))
    rho=float(input("density(Kg/m^3):"))
    sqrt=mdot/(A*Cd)
    deltaP=sqrt**2/2/rho/1000000
    print(f"pressure different:{deltaP}MPa")

def compressible_flow_orifice():
    mdot = 0.18015  # mass flow rate in kg/s
    Cd = 0.7        # discharge coefficient
    rho = 88.46      # density in kg/m^3 (ensure this value is correct)
    Pin = 5e6       # inlet pressure in Pa (5 MPa)
    Pout = 4e6      # outlet pressure in Pa (4 MPa)
    gamma = 1.31     # specific heat ratio for oxygen
    # Calculate orifice area in m^2
    A = mdot / (Cd * math.sqrt(2 * rho * Pin * (gamma / (gamma - 1)) * ((Pout / Pin)**(2 / gamma) - (Pout / Pin)**((gamma + 1) / gamma))))
    # Convert orifice area to mm²
    A_mm2 = A * 1e6
    # Calculate orifice diameter in mm
    d = math.sqrt(A / math.pi) * 2 * 1e3
    print(f"Orifice area: {A_mm2:.6f} mm²")
    print(f"Orifice diameter: {d:.6f} mm")

# Run the function
compressible_flow_orifice()