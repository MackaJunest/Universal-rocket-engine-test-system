import sys
import os
os.environ["QT_SCALE_FACTOR"] = "0.7"  # Adjust as needed
from PyQt6.QtWidgets import QApplication, QMainWindow
from PyQt6.QtCore import Qt
from PyQt6 import uic

app = QApplication(sys.argv)

# Enable DPI scaling for better accuracy

window = QMainWindow()
uic.loadUi("Design.ui", window)
window.show()
sys.exit(app.exec())