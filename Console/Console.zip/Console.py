import sys
from PyQt6 import QtGui

class ConsoleOutput:
    def __init__(self, console_widget):
        self.console_widget = console_widget
        self.stdout = sys.stdout
        self.stderr = sys.stderr
        sys.stdout = self   
        sys.stderr = self

    def write(self, message):
        self.console_widget.moveCursor(QtGui.QTextCursor.MoveOperation.End)
        self.console_widget.insertPlainText(message)
        self.console_widget.ensureCursorVisible()

        # Also write to the terminal
        self.stdout.write(message)
        self.stdout.flush()
        
    def flush(self):
        pass


def setup_console(ui):
    console = ConsoleOutput(ui.Console)
    return console
