#pyuic6 Design.ui -o UI.py    # Convert .ui file to .py file
import sys 
import os 
os.environ["QT_SCALE_FACTOR"] = "0.7"  # Adjust as needed
import csv 
from PyQt6 import QtGui
from PyQt6.QtWidgets import QApplication, QMainWindow, QVBoxLayout
from PyQt6.QtCore import QTimer, QTime, Qt
from Serial import LoRa
from UI import Ui_MainWindow
import pyqtgraph as pg
import datetime

def mapf(val, in_min, in_max, out_min, out_max):
    return (val - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

itotal = 0

class ConsoleOutput:
    def __init__(self, console_widget):
        self.console_widget = console_widget
        self.stdout = sys.stdout
        self.stderr = sys.stderr
        sys.stdout = self   
        sys.stderr = self

    def write(self, message):
        self.console_widget.moveCursor(QtGui.QTextCursor.MoveOperation.End)
        self.console_widget.insertPlainText(message)
        self.console_widget.ensureCursorVisible()

        # Also write to the terminal
        self.stdout.write(message)
        self.stdout.flush()
        
    def flush(self):
        pass


def setup_console(ui):
    console = ConsoleOutput(ui.Console)
    return console



class PlotManager:
    def __init__(self, canvas):
        self.canvas = canvas

        self.PLOT_PUEL_PUMP_HEAD = self.canvas.addPlot(row=0, col=0, title="Fuel pump(MPa)")
        self.PLOT_OXIDIZER_FEED_PRESSURE = self.canvas.addPlot(row=0, col=1, title="Oxidizer feed pressure(MPa)")
        self.PLOT_FUEL_INJECTION_PRESSURE = self.canvas.addPlot(row=1, col=0, title="Fuel injection pressure(MPa)")
        self.PLOT_OXIDIZER_INJECTION_PRESSURE = self.canvas.addPlot(row=0, col=2, title="Oxidizer injection pressure(MPa)")
        self.PLOT_THRUST = self.canvas.addPlot(row=1, col=1, colspan=2, title="Thrust(kgf)")

        self.CURVE_PUEL_PUMP_HEAD = self.PLOT_PUEL_PUMP_HEAD.plot(pen='b')
        self.CURVE_OXIDIZER_FEED_PRESSURE = self.PLOT_OXIDIZER_FEED_PRESSURE.plot(pen='g')
        self.CURVE_FUEL_INJECTION_PRESSURE = self.PLOT_FUEL_INJECTION_PRESSURE.plot(pen='r')
        self.CURVE_OXIDIZER_INJECTION_PRESSURE = self.PLOT_OXIDIZER_INJECTION_PRESSURE.plot(pen='c')
        self.CURVE_THRUST = self.PLOT_THRUST.plot(pen='w')

        self.ELASPED_TIME = []
        self.DATA_PUEL_PUMP_HEAD = []
        self.DATA_OXIDIZER_FEED_PRESSURE = []
        self.DATA_FUEL_INJECTION_PRESSURE = []
        self.DATA_OXIDIZER_INJECTION_PRESSURE = []
        self.DATA_THRUST = []

    def update_curves(self, ELASPED_TIME):
        indices = range(len(ELASPED_TIME))
        self.CURVE_PUEL_PUMP_HEAD.setData(indices, self.DATA_PUEL_PUMP_HEAD)
        self.CURVE_OXIDIZER_FEED_PRESSURE.setData(indices, self.DATA_OXIDIZER_FEED_PRESSURE)
        self.CURVE_FUEL_INJECTION_PRESSURE.setData(indices, self.DATA_FUEL_INJECTION_PRESSURE)
        self.CURVE_OXIDIZER_INJECTION_PRESSURE.setData(indices, self.DATA_OXIDIZER_INJECTION_PRESSURE)
        self.CURVE_THRUST.setData(indices, self.DATA_THRUST)

        self.adjust_x_axis(self.PLOT_PUEL_PUMP_HEAD, ELASPED_TIME)
        self.adjust_x_axis(self.PLOT_OXIDIZER_FEED_PRESSURE, ELASPED_TIME)
        self.adjust_x_axis(self.PLOT_FUEL_INJECTION_PRESSURE, ELASPED_TIME)
        self.adjust_x_axis(self.PLOT_OXIDIZER_INJECTION_PRESSURE, ELASPED_TIME)
        self.adjust_x_axis(self.PLOT_THRUST, ELASPED_TIME)

        # --- Auto-scroll logic ---
        window_size = 100  # Number of points to show (adjust as needed)
        if len(indices) > window_size:
            x_min = len(indices) - window_size
            x_max = len(indices)
        else:
            x_min = 0
            x_max = window_size

        # Set the visible x-range for each plot
        self.PLOT_PUEL_PUMP_HEAD.setXRange(x_min, x_max)
        self.PLOT_OXIDIZER_FEED_PRESSURE.setXRange(x_min, x_max)
        self.PLOT_FUEL_INJECTION_PRESSURE.setXRange(x_min, x_max)
        self.PLOT_OXIDIZER_INJECTION_PRESSURE.setXRange(x_min, x_max)
        self.PLOT_THRUST.setXRange(x_min, x_max)

    def adjust_x_axis(self, plot, ELASPED_TIME):
        # Dynamically adjust x-axis labels
        ticks = []
        num_ticks = 8 # Adjust number of ticks
        data_len = len(ELASPED_TIME)

        if data_len > num_ticks:
            step = max(1, data_len // num_ticks)  # Ensure step is at least 1
            ticks = [(i, ELASPED_TIME[i]) for i in range(0, data_len, step)]
        else:
            ticks = [(i, ELASPED_TIME[i]) for i in range(data_len)]

        # Ensure start label is included
        if data_len > 0:
            ticks = [(0, ELASPED_TIME[0])] + ticks

        plot.getAxis('bottom').setTicks([ticks])
        plot.getAxis('bottom').setLabel("Time")

    def reset_plot(self, plot, ydata):
        if self.ELASPED_TIME:
            x_min = 0
            x_max = len(self.ELASPED_TIME)
            plot.setRange(xRange=[x_min, x_max], yRange=[min(ydata) if ydata else 0, max(ydata) if ydata else 1])
            plot.enableAutoRange()


class TimerManager:
    def __init__(self, plot_manager, csv_manager, lora, ui, datatoesp, main_window):
        self.plot_manager = plot_manager
        self.lora = lora
        self.last_time = None  # Initialize last_time
        self.ui = ui
        self.csv_manager = csv_manager
        self.ELASPED_TIME = plot_manager.ELASPED_TIME
        self.DATA_PUEL_PUMP_HEAD = plot_manager.DATA_PUEL_PUMP_HEAD
        self.DATA_OXIDIZER_FEED_PRESSURE = plot_manager.DATA_OXIDIZER_FEED_PRESSURE
        self.DATA_FUEL_INJECTION_PRESSURE = plot_manager.DATA_FUEL_INJECTION_PRESSURE
        self.DATA_OXIDIZER_INJECTION_PRESSURE = plot_manager.DATA_OXIDIZER_INJECTION_PRESSURE
        self.DATA_THRUST = plot_manager.DATA_THRUST
        self.timer = QTimer()
        self.timer.setInterval(5)
        self.timer.timeout.connect(self.update_system)
        self.timer_active = False
        self.total_Impulse = []  # Initialize total_Impulse as an array
        self.datatoesp = datatoesp
        self.main_window = main_window  # Store reference to MainWindow

    def start_graphing(self):
        print("Start Graphing")
        if not self.timer_active:
            self.t0 = datetime.datetime.now()
            self.timer.start()
            self.timer_active = True

    def stop_graphing(self):
        print("Stop Graphing")
        if self.timer_active:
            self.timer.stop()
            self.timer_active = False

    def update_system(self):
        global P_FUEL_PUMP, P_OX_FEED, P_FUEL_INJ, P_OX_INJ, P_PURGE_TANK, Thrust, TEMP_D_SEC, TEMP_T_SEC, TEMP_C_SEC, TEMP_C_INLET, TEMP_CHAMBER, FUEL_VALVE, OXIDIZER_VALVE, PUMP_SPEED, itotal
        # Get current time and calculate elapsed time
        current_time = datetime.datetime.now()
        elapsed_time = (current_time - self.t0).total_seconds()

        # Format time for display
        formatted_time = current_time.strftime("%H:%M:%S:%f")[:-3]  # HH:MM:SS:MS
        display_time = f"{formatted_time} ({elapsed_time:.0f}s)"

        telemetry_data = self.lora.receive_telemetry()
        if telemetry_data:
            (P_FUEL_PUMP, P_OX_FEED, P_FUEL_INJ, P_OX_INJ, P_PURGE_TANK, Thrust,
            FUEL_VALVE, OXIDIZER_VALVE, PUMP_SPEED) = telemetry_data

            # Update sliders and value boxes dynamically in auto control mode
            if self.main_window.MANUEL_CONTROLL_STA == 0:  # Check if auto control is enabled
                # Update V1 (Fuel Valve)
                self.ui.V1Slide.blockSignals(True)
                self.ui.V1Slide.setValue(FUEL_VALVE)
                self.ui.V1Slide.blockSignals(False)

                self.ui.V1Box.blockSignals(True)
                self.ui.V1Box.setValue(FUEL_VALVE)
                self.ui.V1Box.blockSignals(False)

                # Update V2 (Oxidizer Valve)
                self.ui.V2Slide.blockSignals(True)
                self.ui.V2Slide.setValue(OXIDIZER_VALVE)
                self.ui.V2Slide.blockSignals(False)

                self.ui.V2Box.blockSignals(True)
                self.ui.V2Box.setValue(OXIDIZER_VALVE)
                self.ui.V2Box.blockSignals(False)

                # Update PU1 (Pump Speed)
                self.ui.PU1Slide.blockSignals(True)
                self.ui.PU1Slide.setValue(PUMP_SPEED)
                self.ui.PU1Slide.blockSignals(False)

                self.ui.PU1Box.blockSignals(True)
                self.ui.PU1Box.setValue(PUMP_SPEED)
                self.ui.PU1Box.blockSignals(False)

            # Map telemetry data to the plot
            self.ELASPED_TIME.append(display_time)
            self.DATA_PUEL_PUMP_HEAD.append(mapf(P_FUEL_PUMP, 4000, 20000, 0.000, 16.000))
            self.DATA_OXIDIZER_FEED_PRESSURE.append(mapf(P_OX_FEED, 4000, 20000, 0.000, 16.000))
            self.DATA_FUEL_INJECTION_PRESSURE.append(mapf(P_FUEL_INJ, 4000, 20000, 0.000, 16.000))
            self.DATA_OXIDIZER_INJECTION_PRESSURE.append(mapf(P_OX_INJ, 4000, 20000, 0.000, 16.000))
            self.DATA_THRUST.append(mapf(Thrust, 4000, 20000, 0.000, 200.000))
            #self.ui.T_CHAMBER.setText(f"CHAMBER: {TEMP_CHAMBER:.2f} C")
            #self.ui.T_CON_IN.setText(f"C IN: {TEMP_C_INLET:.2f} C")
            #self.ui.T_CON_SEC.setText(f"C SEC: {TEMP_C_SEC:.2f} C")
            #self.ui.T_THOAT.setText(f"THOAT: {TEMP_T_SEC:.2f} C")
            #self.ui.T_DIV_SEC.setText(f"D SEC: {TEMP_D_SEC:.2f} C")
            self.ui.P_PURGE.setText(f"PURGE: {mapf(P_PURGE_TANK, 4000, 20000, 0.000, 16.000):.2f} MPa")
            # Update the plot
            self.plot_manager.update_curves(self.ELASPED_TIME)

            # Calculate Itotal if recording is active
            if record_Itotal:
                thrust_in_newtons = mapf(Thrust, 4000, 20000, 0.000, 200.000) * 9.812  # Convert thrust to Newtons
                if self.last_time is not None:
                    time_diff = (current_time - self.last_time).total_seconds()
                    if time_diff > 0:  # Ensure time_diff is positive
                        itotal += thrust_in_newtons * time_diff  # Accumulate impulse
                self.last_time = current_time  # Update last_time

            # Append the telemetry data to the CSV file
            self.csv_manager.append_to_csv(
                display_time,
                mapf(P_FUEL_PUMP, 4000, 20000, 0.000, 16.000),
                mapf(P_OX_FEED, 4000, 20000, 0.000, 16.000),
                mapf(P_FUEL_INJ, 4000, 20000, 0.000, 16.000),
                mapf(P_OX_INJ, 4000, 20000, 0.000, 16.000),
                mapf(Thrust, 4000, 20000, 0.000, 200.000),
                itotal,
                self.datatoesp,
                FUEL_VALVE,
                OXIDIZER_VALVE,
                PUMP_SPEED
            )

            # Update the UI (optional)
            self.ui.Itotal.setText(f"Itotal: {itotal:.2f} Ns")

# CSV saving class
class CSVManager:
    def __init__(self, file_name=None):
        if file_name is None:
            # Replace invalid characters in the timestamp
            timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            file_name = f"telemetry_{timestamp}.csv"
        self.file_name = file_name
        # Write the header to the CSV file when the manager is initialized
        with open(self.file_name, mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['Time', 'Fuel Pump Pressure', 'Oxidizer Feed Pressure', 'Fuel Injection Pressure', 'Oxidizer Injection Pressure', 'Thrust', 'Itotal', 'ESTOP_STA', 'ARM_STA', 'MANUEL_CONTROLL_STA', 'V_OX_STA', 'V_FU_STA', 'PUMP_STA', 'PURGE_STA', 'IGNITOR_STA', 'IGN_SQ_STA', 'FUEL_VALVE_DATA', 'OXIDIZER_VALVE_DATA', 'PUMP_SPEED_DATA'])
            
    def append_to_csv(self, time, fuel_pump, oxidizer_feed, fuel_injection, oxidizer_injection, thrust, itotal, datatoesp, FUEL_VALVE_DATA, OXIDIZER_VALVE_DATA, PUMP_SPEED_DATA):
        # Append a single row of telemetry data to the CSV file
        with open(self.file_name, mode='a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([time,
                fuel_pump,
                oxidizer_feed,
                fuel_injection,
                oxidizer_injection,
                thrust,
                itotal, 
                datatoesp[0],
                datatoesp[1],
                datatoesp[2],
                datatoesp[3],
                datatoesp[4],
                datatoesp[5],
                datatoesp[6],
                datatoesp[7],
                datatoesp[8],
                FUEL_VALVE_DATA,
                OXIDIZER_VALVE_DATA,
                PUMP_SPEED_DATA
                ])

class MainWindow:
    def __init__(self):
        self.ESTOP_STA = 0      # Estop status
        self.ARM_STA = 0        # Arm status
        self.MANUEL_CONTROLL_STA = 0 # Manuel control status
        self.V_OX_STA = 0       # Oxidizer valve status
        self.V_FU_STA = 0       # Fuel valve status
        self.PUMP_STA = 0       # Pump status
        self.PURGE_STA = 0      # Purge status
        self.IGNITOR_STA = 0    # Ignitor status
        self.IGN_SQ_STA = 0     # Ignition sequence status

        self.main_win = QMainWindow()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self.main_win)

        # Initialize LoRa object for serial communication
        self.lora = LoRa()
        self.lora.COM_INIT()

        self.csv_manager = CSVManager()

        # Set the initial page of the stacked widget (home page)
        self.ui.stackedWidget.setCurrentWidget(self.ui.Telem)

        # Set initial state to auto_controll
        self.auto_controll()

        # Set initial system status to disarmed
        self.System_status = "Disarmed"

        # Set up the console
        self.console = setup_console(self.ui)
        print(f"status: {self.System_status}")

        # Ensure the datawidget has a layout
        if self.ui.datawidget.layout() is None:
            layout = QVBoxLayout()
            self.ui.datawidget.setLayout(layout)

        # Initialize timer for hold functionality
        self.hold_timer = QTimer()
        self.hold_timer.setInterval(3000)  # 3000 milliseconds = 3 seconds
        self.hold_timer.timeout.connect(self.execute_ig_sq_action)

        # Initialize purge timer
        self.purge_timer = QTimer()
        self.purge_timer.setInterval(200)  # 200 milliseconds
        self.purge_timer.timeout.connect(self.CO2Purge_Pressed)

        # Initialize countdown timer
        self.countdown_timer = QTimer()
        self.countdown_timer.setInterval(1000)  # 1-second interval
        self.countdown_timer.timeout.connect(self.update_countdown)

        self.countdown_time = QTime(0, 0)  # Start with 00:00:00
        self.start_time = None
        self.countdown_active = False
        self.engaged = False

        self.ui.SRMChecklsBT.clicked.connect(self.showSRMCheckls)
        self.ui.LRMChecklsBT.clicked.connect(self.showLRMCheckls)
        self.ui.TelemBT.clicked.connect(self.showTelem)
        self.ui.TelemStart.clicked.connect(self.start_telemetry)
        self.ui.TelemStop.clicked.connect(self.stop_telemetry)
        self.ui.ManON.clicked.connect(self.manuel_controll)
        self.ui.ManOFF.clicked.connect(self.auto_controll)
        self.ui.Arm.clicked.connect(self.sysArm)
        self.ui.Disarm.clicked.connect(self.sysDisarm)
        self.ui.IGSQ.pressed.connect(self.start_hold_timer)
        self.ui.IGSQ.released.connect(self.stop_hold_timer)
        self.ui.PurgeBT.pressed.connect(self.start_purge_timer)
        self.ui.PurgeBT.released.connect(self.stop_purge_timer)
        self.ui.Estop.clicked.connect(self.handle_estop)  # Connect Estop button
        self.ui.SRMRST.clicked.connect(self.reset_SRMchecklist)
        self.ui.LRMRST.clicked.connect(self.reset_LRMchecklist)
        self.ui.IgnitorBT.clicked.connect(self.Ignitor_Control)
        
        # Connect reset buttons
        self.ui.RST1.clicked.connect(lambda: self.reset_plot(self.plot_manager.PLOT_PUEL_PUMP_HEAD, self.plot_manager.DATA_PUEL_PUMP_HEAD))
        self.ui.RST2.clicked.connect(lambda: self.reset_plot(self.plot_manager.PLOT_OXIDIZER_FEED_PRESSURE, self.plot_manager.DATA_OXIDIZER_FEED_PRESSURE))
        self.ui.RST3.clicked.connect(lambda: self.reset_plot(self.plot_manager.PLOT_FUEL_INJECTION_PRESSURE, self.plot_manager.DATA_FUEL_INJECTION_PRESSURE))
        self.ui.RST4.clicked.connect(lambda: self.reset_plot(self.plot_manager.PLOT_OXIDIZER_INJECTION_PRESSURE, self.plot_manager.DATA_OXIDIZER_INJECTION_PRESSURE))
        self.ui.RST5.clicked.connect(lambda: self.reset_plot(self.plot_manager.PLOT_THRUST, self.plot_manager.DATA_THRUST))

        self.canvas = pg.GraphicsLayoutWidget()
        self.ui.datawidget.layout().addWidget(self.canvas)

        # Connect slider and spinbox
        self.ui.V1Slide.valueChanged.connect(self.V1update_spinbox_from_slider)
        self.ui.V1Box.valueChanged.connect(self.V1update_slider_from_spinbox)
        self.ui.V2Slide.valueChanged.connect(self.V2update_spinbox_from_slider)
        self.ui.V2Box.valueChanged.connect(self.V2update_slider_from_spinbox)
        self.ui.PU1Slide.valueChanged.connect(self.PU1update_spinbox_from_slider)
        self.ui.PU1Box.valueChanged.connect(self.PU1update_slider_from_spinbox)

        self.datatoesp = [0] * 9  # Initialize datatoesp with 9 elements

        # Set up a timer to update datatoesp periodically
        self.update_timer = QTimer()
        self.update_timer.setInterval(100)  # Update every 100 ms
        self.update_timer.timeout.connect(self.update_datatoesp)
        self.update_timer.start()


        self.plot_manager = PlotManager(self.canvas)
        self.timer_manager = TimerManager(self.plot_manager, self.csv_manager, self.lora, self.ui, self.datatoesp, self)  # Pass CSVManager
        
    def update_datatoesp(self):
        self.datatoesp[0] = self.ESTOP_STA
        self.datatoesp[1] = self.ARM_STA
        self.datatoesp[2] = self.MANUEL_CONTROLL_STA
        self.datatoesp[3] = self.V_OX_STA
        self.datatoesp[4] = self.V_FU_STA
        self.datatoesp[5] = self.PUMP_STA
        self.datatoesp[6] = self.PURGE_STA
        self.datatoesp[7] = self.IGNITOR_STA
        self.datatoesp[8] = self.IGN_SQ_STA
        self.lora.send_data(*self.datatoesp)

    def start_telemetry(self):
        self.timer_manager.start_graphing()

    def stop_telemetry(self):
        self.timer_manager.stop_graphing()

    def reset_plot(self, plot, ydata):
        self.plot_manager.reset_plot(plot, ydata)

    def show(self):
        self.main_win.show()

    def showSRMCheckls(self):
        self.ui.stackedWidget.setCurrentWidget(self.ui.SRMcheckls)

    def showLRMCheckls(self):
        self.ui.stackedWidget.setCurrentWidget(self.ui.LRMcheckls)

    def showTelem(self):
        self.ui.stackedWidget.setCurrentWidget(self.ui.Telem)

    def reset_SRMchecklist(self):
        for i in range(1, 13):
            checkbox_name = f"checkBox_{i}"
            checkbox = getattr(self.ui, checkbox_name, None)
            if checkbox:
                checkbox.setChecked(False)

    def reset_LRMchecklist(self):
        for i in range(13, 42):
            checkbox_name = f"checkBox_{i}"
            checkbox = getattr(self.ui, checkbox_name, None)
            if checkbox:
                checkbox.setChecked(False)

    def manuel_controll(self):
        self.ui.V1Slide.setEnabled(True)
        self.ui.V1Box.setEnabled(True)
        self.ui.V2Slide.setEnabled(True)
        self.ui.V2Box.setEnabled(True)
        self.ui.PU1Slide.setEnabled(True)
        self.ui.PU1Box.setEnabled(True)
        self.ui.IgnitorBT.setEnabled(True)
        self.MANUEL_CONTROLL_STA=1

    def auto_controll(self):
        self.ui.V1Slide.setEnabled(False)
        self.ui.V1Box.setEnabled(False)
        self.ui.V2Slide.setEnabled(False)
        self.ui.V2Box.setEnabled(False)
        self.ui.PU1Slide.setEnabled(False)
        self.ui.PU1Box.setEnabled(False)
        self.ui.IgnitorBT.setEnabled(False)
        self.MANUEL_CONTROLL_STA=0

    def V1update_spinbox_from_slider(self, value):
        self.ui.V1Box.blockSignals(True)
        self.ui.V1Box.setValue(value)
        self.ui.V1Box.blockSignals(False)
        self.V_FU_STA=value

    def V1update_slider_from_spinbox(self, value):
        self.ui.V1Slide.blockSignals(True)
        self.ui.V1Slide.setValue(value)
        self.ui.V1Slide.blockSignals(False)
        self.V_FU_STA=value

    def V2update_spinbox_from_slider(self, value):
        self.ui.V2Box.blockSignals(True)
        self.ui.V2Box.setValue(value)
        self.ui.V2Box.blockSignals(False)
        self.V_OX_STA=value

    def V2update_slider_from_spinbox(self, value):
        self.ui.V2Slide.blockSignals(True)
        self.ui.V2Slide.setValue(value)
        self.ui.V2Slide.blockSignals(False)
        self.V_OX_STA=value

    def PU1update_spinbox_from_slider(self, value):
        self.ui.PU1Box.blockSignals(True)
        self.ui.PU1Box.setValue(value)
        self.ui.PU1Box.blockSignals(False)
        self.PUMP_STA=value

    def PU1update_slider_from_spinbox(self, value):
        self.ui.PU1Slide.blockSignals(True)
        self.ui.PU1Slide.setValue(value)
        self.ui.PU1Slide.blockSignals(False)
        self.PUMP_STA=value

    def CO2Purge_Pressed(self):
        print("CO2 Purge on")
        self.PURGE_STA = 1
        QTimer.singleShot(1000, self.CO2Purge_Released)

    def CO2Purge_Released(self):
        print("CO2 Purge off")
        self.PURGE_STA = 0

    def Ignitor_Control(self):
        if self.IGNITOR_STA == 0:
            print("Ignitor on")
            self.IGNITOR_STA = 1
        else:
            print("Ignitor off")
            self.IGNITOR_STA = 0

    def sysArm(self):
        self.System_status = "Armed"
        self.ARM_STA = 1
        print(f"status: {self.System_status}")
        print("please hold the IGSQ button for 3 seconds to start the ignition sequence")

    def sysDisarm(self):
        self.System_status = "Disarmed"
        self.ARM_STA = 0
        self.IGN_SQ_STA = 0
        print(f"status: {self.System_status}")
        
    def start_hold_timer(self):
        # Start the timer when the button is pressed
        self.hold_timer.start()

    def stop_hold_timer(self):
        # Stop the timer when the button is released
        self.hold_timer.stop()

    def start_purge_timer(self):
        # Start the timer when the button is pressed
        self.purge_timer.start()

    def stop_purge_timer(self):
        # Stop the timer when the button is released
        self.purge_timer.stop()

    def execute_ig_sq_action(self):
        if self.System_status == "Armed" and self.ESTOP_STA == 0:
            # Call ignition method here
            self.auto_controll()
            self.MANUEL_CONTROLL_STA = 0
            self.start_ignition_sequence()

    def start_ignition_sequence(self):
        # Reset engaged flag for a new ignition sequence
        self.engaged = False  # Reset engaged to allow countdown display
        print("Executing ignition sequence...")
        self.countdown_time = QTime(0, 0).addSecs(10)  # Set the countdown time to 10 seconds
        self.countdown_active = True
        self.start_time = datetime.datetime.now()
        self.countdown_timer.start() 
        self.IGN_SQ_STA = 1

    def update_countdown(self):
        global record_Itotal
        if self.countdown_active:
            if self.countdown_time > QTime(0, 0):
                self.countdown_time = self.countdown_time.addSecs(-1)
                self.update_time_display()
                if self.countdown_time <= QTime(0, 0, 1):
                    record_Itotal = True
                    self.IGN_SQ_STA = 0
                    self.ARM_STA = 0
            else:
                self.countdown_active = False
                self.perform_ignition()  # Call the ignition method after countdown

    def update_time_display(self):
        if self.countdown_active and not self.engaged:
            # Display countdown (T-)
            display_time = f"T-{self.countdown_time.toString('mm:ss')}"
        else:
            # Provide a default value for display_time
            display_time = "Pending for countdown"

        self.ui.ELAPSED_TIME.setText(display_time)

    def perform_ignition(self):
        global record_Itotal
        # Perform ignition actions here
        self.ui.ELAPSED_TIME.setText("Ignition!")
        self.engaged = True
        self.sysDisarm()  # Set status to Disarmed
        print("Ignition sequence executed. System disarmed.")

    def handle_estop(self):
        # Stop countdown and timer, and set status to disarmed
        self.ESTOP_STA = 1
        self.countdown_timer.stop()
        self.countdown_active = False
        self.start_time = None
        self.countdown_time = QTime(0, 0)
        self.ui.ELAPSED_TIME.setText("Abort!")  # Reset display time
        print("Abort! Waiting for instruction")
        self.ui.V1Slide.setValue(0)
        self.ui.V2Slide.setValue(0)
        self.ui.PU1Slide.setValue(0)
        self.ui.ManON.setEnabled(True)
        self.sysDisarm()  # Set status to Disarmed

if __name__ == '__main__':
    record_Itotal = False
    app = QApplication(sys.argv)
    app.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    main_win = MainWindow()
    main_win.show()
    sys.exit(app.exec())
