

class PlotManager:
    def __init__(self, canvas):
        self.canvas = canvas

        self.PLOT_PUEL_PUMP_HEAD = self.canvas.addPlot(row=0, col=0, title="Fuel pump(MPa)")
        self.PLOT_OXIDIZER_FEED_PRESSURE = self.canvas.addPlot(row=0, col=1, title="Oxidizer feed pressure(MPa)")
        self.PLOT_FUEL_INJECTION_PRESSURE = self.canvas.addPlot(row=1, col=0, title="Fuel injection pressure(MPa)")
        self.PLOT_OXIDIZER_INJECTION_PRESSURE = self.canvas.addPlot(row=0, col=2, title="Oxidizer injection pressure(MPa)")
        self.PLOT_THRUST = self.canvas.addPlot(row=1, col=1, colspan=2, title="Thrust(kgf)")

        self.CURVE_PUEL_PUMP_HEAD = self.PLOT_PUEL_PUMP_HEAD.plot(pen='b')
        self.CURVE_OXIDIZER_FEED_PRESSURE = self.PLOT_OXIDIZER_FEED_PRESSURE.plot(pen='g')
        self.CURVE_FUEL_INJECTION_PRESSURE = self.PLOT_FUEL_INJECTION_PRESSURE.plot(pen='r')
        self.CURVE_OXIDIZER_INJECTION_PRESSURE = self.PLOT_OXIDIZER_INJECTION_PRESSURE.plot(pen='c')
        self.CURVE_THRUST = self.PLOT_THRUST.plot(pen='w')

        self.ELASPED_TIME = []
        self.DATA_PUEL_PUMP_HEAD = []
        self.DATA_OXIDIZER_FEED_PRESSURE = []
        self.DATA_FUEL_INJECTION_PRESSURE = []
        self.DATA_OXIDIZER_INJECTION_PRESSURE = []
        self.DATA_THRUST = []

    def update_curves(self, ELASPED_TIME):
        indices = range(len(ELASPED_TIME))
        self.CURVE_PUEL_PUMP_HEAD.setData(indices, self.DATA_PUEL_PUMP_HEAD)
        self.CURVE_OXIDIZER_FEED_PRESSURE.setData(indices, self.DATA_OXIDIZER_FEED_PRESSURE)
        self.CURVE_FUEL_INJECTION_PRESSURE.setData(indices, self.DATA_FUEL_INJECTION_PRESSURE)
        self.CURVE_OXIDIZER_INJECTION_PRESSURE.setData(indices, self.DATA_OXIDIZER_INJECTION_PRESSURE)
        self.CURVE_THRUST.setData(indices, self.DATA_THRUST)

        self.adjust_x_axis(self.PLOT_PUEL_PUMP_HEAD, ELASPED_TIME)
        self.adjust_x_axis(self.PLOT_OXIDIZER_FEED_PRESSURE, ELASPED_TIME)
        self.adjust_x_axis(self.PLOT_FUEL_INJECTION_PRESSURE, ELASPED_TIME)
        self.adjust_x_axis(self.PLOT_OXIDIZER_INJECTION_PRESSURE, ELASPED_TIME)
        self.adjust_x_axis(self.PLOT_THRUST, ELASPED_TIME)

        # --- Auto-scroll logic ---
        window_size = 100  # Number of points to show (adjust as needed)
        if len(indices) > window_size:
            x_min = len(indices) - window_size
            x_max = len(indices)
        else:
            x_min = 0
            x_max = window_size

        # Set the visible x-range for each plot
        self.PLOT_PUEL_PUMP_HEAD.setXRange(x_min, x_max)
        self.PLOT_OXIDIZER_FEED_PRESSURE.setXRange(x_min, x_max)
        self.PLOT_FUEL_INJECTION_PRESSURE.setXRange(x_min, x_max)
        self.PLOT_OXIDIZER_INJECTION_PRESSURE.setXRange(x_min, x_max)
        self.PLOT_THRUST.setXRange(x_min, x_max)

    def adjust_x_axis(self, plot, ELASPED_TIME):
        # Dynamically adjust x-axis labels
        ticks = []
        num_ticks = 8 # Adjust number of ticks
        data_len = len(ELASPED_TIME)

        if data_len > num_ticks:
            step = max(1, data_len // num_ticks)  # Ensure step is at least 1
            ticks = [(i, ELASPED_TIME[i]) for i in range(0, data_len, step)]
        else:
            ticks = [(i, ELASPED_TIME[i]) for i in range(data_len)]

        # Ensure start label is included
        if data_len > 0:
            ticks = [(0, ELASPED_TIME[0])] + ticks

        plot.getAxis('bottom').setTicks([ticks])
        plot.getAxis('bottom').setLabel("Time")

    def reset_plot(self, plot, ydata):
        if self.ELASPED_TIME:
            x_min = 0
            x_max = len(self.ELASPED_TIME)
            plot.setRange(xRange=[x_min, x_max], yRange=[min(ydata) if ydata else 0, max(ydata) if ydata else 1])
            plot.enableAutoRange()
